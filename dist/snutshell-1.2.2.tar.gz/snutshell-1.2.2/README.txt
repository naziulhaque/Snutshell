A library for storing numeric data in dat and xlsx format

see the documentation at https://github.com/naziulhaque/Snutshell/blob/master/README.md