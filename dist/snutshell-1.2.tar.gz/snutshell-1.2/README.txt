A library for storing numeric data in dat and xlsx format
